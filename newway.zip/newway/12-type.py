# -*- coding: utf-8 -*-
"""
Created on Sat Oct 13 15:14:51 2018

@author: Xinyi
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from sklearn.datasets.samples_generator import make_blobs

X, y = make_blobs(n_samples=50000, n_features=3, centers=[[255,0,0], [255,127,0], [255,255,0], [127,255,0], [0,255,0], [0,255,127], [0,255,255],[0,127,255], [0,0,255],[127,0,255],[255,0,255],[255,0,127]], cluster_std=[20,10,20,10,20,10,20,10,20,10,20,10])
X_int = np.rint(X)

df = pd.DataFrame(X_int, columns = ['R','G','B'])
df['label'] = y
lable_dic = {0:"Red", 1:"Orange", 2:"Yellow", 3:"Chartreuse Green", 4:"Green", 5:"Spring Green", 6:"Cyan", 7:"Azure", 8:"Blue", 9:"Violet", 10:"Magenta", 11:"Rose"}
DataSet = df[ (df['R'] <=255) & (df['R'] >=0) & (df['G'] <=255) & (df['G'] >=0) & (df['B'] <=255) & (df['B'] >=0)]
DataSet['Color type'] = DataSet['label'].map(lable_dic)
DataSet = DataSet.drop(columns = ['label'])

Red = DataSet[ DataSet['Color type'] == "Red"]
Orange = DataSet[ DataSet['Color type'] == "Orange"]
Yellow = DataSet[ DataSet['Color type'] == "Yellow"]
Chartreuse_Green = DataSet[ DataSet['Color type'] == "Chartreuse Green"]
Green = DataSet[ DataSet['Color type'] == "Green"]
Spring_Green = DataSet[ DataSet['Color type'] == "Spring Green"]
Cyan = DataSet[ DataSet['Color type'] == "Cyan"]
Azure = DataSet[ DataSet['Color type'] == "Azure"]
Blue = DataSet[ DataSet['Color type'] == "Blue"]
Violet = DataSet[ DataSet['Color type'] == "Violet"]
Magenta = DataSet[ DataSet['Color type'] == "Magenta"]
Rose = DataSet[ DataSet['Color type'] == "Rose"]

fig = plt.figure()
ax = Axes3D(fig)

ax.scatter(Red['R'], Red['G'], Red['B'], color = "#ff0000")
ax.scatter(Orange['R'], Orange['G'], Orange['B'], color = "#ff7f00")
ax.scatter(Yellow['R'], Yellow['G'], Yellow['B'], color = "#ffff00")
ax.scatter(Chartreuse_Green['R'], Chartreuse_Green['G'], Chartreuse_Green['B'], color = "#7fff00")
ax.scatter(Green['R'], Green['G'], Green['B'], color = "#00ff00")
ax.scatter(Spring_Green['R'], Spring_Green['G'], Spring_Green['B'], color = "#00ff7f")
ax.scatter(Cyan['R'], Cyan['G'], Cyan['B'], color = "#00ffff")
ax.scatter(Azure['R'], Azure['G'], Azure['B'], color = "#007fff")
ax.scatter(Blue['R'], Blue['G'], Blue['B'], color = "#0000ff")
ax.scatter(Violet['R'], Violet['G'], Violet['B'], color = "#7f00ff")
ax.scatter(Magenta['R'], Magenta['G'], Magenta['B'], color = "#ff00ff")
ax.scatter(Rose['R'], Rose['G'], Rose['B'], color = "#ff007f")
           
           
           
           
DataSet.to_csv('dataset.csv', encoding = 'utf-8-sig',index = False)