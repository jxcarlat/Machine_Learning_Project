# -*- coding: utf-8 -*-
"""
Created on Sat Oct 13 16:10:40 2018

@author: Xinyi
"""
import training 

import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
import numpy as np



dataset = pd.read_csv('dataset.csv')
feature_columns = ['R', 'G', 'B']
X = dataset[feature_columns].values
y = dataset['Color type'].values

from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
y = le.fit_transform(y)


knn = KNeighborsClassifier(n_neighbors = 10)
knn.fit(X, y)

#get the image were trying to predict
x_unknown = training.getRGBValues("1.jpg")
#x_unknown = np.array([194,165,115])


#predict
prediction = knn.predict(np.array(x_unknown).reshape(1,3))



print(le.inverse_transform(prediction))