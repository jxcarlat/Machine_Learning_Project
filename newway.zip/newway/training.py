import os
import cv2
import numpy as np

def training():
    dataFile = open("data.txt", "w") #open file for writing the data

     # black color training images
    for f in os.listdir('./images/black'):
        values = getRGBValues('./images/black/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("black" + "\n")

    # blue color training images
    for f in os.listdir('./images/blue'):
        values = getRGBValues('./images/blue/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("blue" + "\n")

    # cyan color training images
    for f in os.listdir('./images/cyan'):
        values = getRGBValues('./images/cyan/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("cyan" + "\n")

    # gray color training images
    for f in os.listdir('./images/gray'):
        values = getRGBValues('./images/gray/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("gray" + "\n")

    # green color training images
    for f in os.listdir('./images/green'):
        values = getRGBValues('./images/green/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("green" + "\n")

    # magenta color training images
    for f in os.listdir('./images/magenta'):
        values = getRGBValues('./images/magenta/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("magenta" + "\n")

    # red color training images
    for f in os.listdir('./images/red'):
        values = getRGBValues('./images/red/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("red" + "\n")

    # silver color training images
    for f in os.listdir('./images/silver'):
        values = getRGBValues('./images/silver/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("silver" + "\n")

    # white color training images
    for f in os.listdir('./images/white'):
        values = getRGBValues('./images/white/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("white" + "\n")

    # yellow color training images
    for f in os.listdir('./images/yellow'):
        values = getRGBValues('./images/yellow/' + f) # get the peak RGB values
        for colorValue in values: # print to file
            dataFile.write(str(colorValue) + ",")
        dataFile.write("yellow" + "\n")
        

# returns the peak values for each RGB channels
def getRGBValues(img_src):
    image = cv2.imread(img_src)
    bgr_planes = cv2.split(image)

    blueHist = cv2.calcHist(bgr_planes, [0], None, [256], [0, 256])
    greenHist = cv2.calcHist(bgr_planes, [1], None, [256], [0, 256])
    redHist = cv2.calcHist(bgr_planes, [2], None, [256], [0, 256])

    return([np.argmax(redHist), np.argmax(greenHist), np.argmax(blueHist)])

'''
def main():
    training()

if __name__ == '__main__':
    main()

'''